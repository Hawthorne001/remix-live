"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([[3207],{

/***/ 43207:
/***/ ((module) => {

module.exports = JSON.parse('{"$schema":"https://sindri.app/api/v1/sindri-manifest-schema.json","name":"circuit_name","circuitPath":"./circuits/circuit.circom","circuitType":"circom","curve":"bn254","provingScheme":"groth16","witnessCompiler":"wasm"}');

/***/ })

}]);